"""Map LangGraph stream events → AgentEventOccurred + accumulate trace.

The graph is a deterministic pipeline: every agent contributes in turn, then a
``synthesizer`` node merges the contributions into the final answer. So:

* each agent's output becomes a trace entry (the per-competence detail the UI
  shows under "Внесок команди");
* the synthesizer's output becomes ``final_output`` (the summary shown as the
  assistant's main reply).
"""

from dataclasses import dataclass, field
from typing import Any
from uuid import UUID

from langchain_core.messages import AIMessage, BaseMessage

from agentforge_worker.contracts import AgentEventOccurred, TraceEntry

SUMMARY_ROLE = "summary"
_PREVIEW_LIMIT = 200


def _preview(text: str) -> str:
    text = (text or "").strip()
    return text if len(text) <= _PREVIEW_LIMIT else text[:_PREVIEW_LIMIT] + "..."


def _node_role(node_name: str) -> str | None:
    if node_name and node_name.startswith("agent_"):
        return node_name[len("agent_") :]
    return None


def _extract_message_content(msg: BaseMessage | None) -> str:
    if msg is None:
        return ""
    content = getattr(msg, "content", "")
    if isinstance(content, str):
        return content
    return str(content)


@dataclass
class _AgentRun:
    role: str
    tools_used: list[str] = field(default_factory=list)
    last_output: str = ""


@dataclass
class SessionAccumulator:
    """Collects per-agent traces while a session streams."""

    session_id: UUID
    conversation_id: UUID
    iterations: int = 0
    trace: list[TraceEntry] = field(default_factory=list)
    final_output: str = ""
    # Fallback used if the synthesizer produces nothing.
    last_agent_output: str = ""
    _current_agent: dict[str, _AgentRun] = field(default_factory=dict)

    def make_event(
        self,
        event_type: str,
        agent_role: str | None,
        payload: dict[str, Any],
    ) -> AgentEventOccurred:
        return AgentEventOccurred(
            session_id=self.session_id,
            conversation_id=self.conversation_id,
            event_type=event_type,  # type: ignore[arg-type]
            agent_role=agent_role,
            payload=payload,
        )


def map_event(ev: dict, acc: SessionAccumulator) -> AgentEventOccurred | None:
    """Convert a single LangGraph astream_events item into AgentEventOccurred (or None to skip)."""

    kind = ev.get("event")
    name = ev.get("name", "")
    data = ev.get("data", {}) or {}
    metadata = ev.get("metadata", {}) or {}
    langgraph_node = metadata.get("langgraph_node")

    # ── an agent starts working ──
    if kind == "on_chain_start" and name.startswith("agent_"):
        role = _node_role(name)
        if role:
            acc._current_agent[role] = _AgentRun(role=role)
            return acc.make_event("agent_started", role, {})
        return None

    # ── the synthesizer starts composing the summary ──
    if kind == "on_chain_start" and name == "synthesizer":
        return acc.make_event("agent_started", SUMMARY_ROLE, {})

    if kind == "on_tool_start":
        role = _node_role(langgraph_node) if langgraph_node else None
        if role and role in acc._current_agent:
            acc._current_agent[role].tools_used.append(name)
        return acc.make_event(
            "tool_called",
            role,
            {"tool": name, "input": data.get("input")},
        )

    if kind == "on_tool_end":
        role = _node_role(langgraph_node) if langgraph_node else None
        out = data.get("output")
        return acc.make_event(
            "tool_result",
            role,
            {"tool": name, "output_preview": _preview(str(out))},
        )

    # ── an agent finished its contribution → record it in the trace ──
    if kind == "on_chain_end" and name.startswith("agent_"):
        role = _node_role(name)
        text = _extract_agent_text(data)
        run = acc._current_agent.get(role) if role else None
        tools_used = list(run.tools_used) if run else []
        if role and run:
            run.last_output = text
            # Agents tag output as "[role]: <content>". A repeated/redundant
            # turn can yield empty content; skip blank steps.
            prefix = f"[{role}]: "
            real = text[len(prefix):] if text.startswith(prefix) else text
            if real.strip():
                acc.trace.append(
                    TraceEntry(agent_role=role, output=text, tools_used=tools_used)
                )
                acc.iterations += 1
                acc.last_agent_output = text
        return acc.make_event(
            "agent_finished",
            role,
            {"output_preview": _preview(text), "tools_used": tools_used},
        )

    # ── the synthesizer finished → its output is the final answer ──
    if kind == "on_chain_end" and name == "synthesizer":
        text = _extract_agent_text(data).strip()
        if text:
            acc.final_output = text
        return acc.make_event(
            "agent_finished",
            SUMMARY_ROLE,
            {"output_preview": _preview(text)},
        )

    return None


def _extract_agent_text(data: dict) -> str:
    """Pull the last message's text from a node's output payload."""
    output = data.get("output") or {}
    msgs = output.get("messages") if isinstance(output, dict) else None
    msgs = msgs or []
    last_msg = msgs[-1] if msgs else None
    if isinstance(last_msg, AIMessage):
        return _extract_message_content(last_msg)
    if last_msg is not None:
        return _extract_message_content(last_msg)
    return ""
